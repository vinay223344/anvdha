import java.util.*;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array");
        int size = sc.nextInt();

        if (size <= 0) {
            System.out.println(size + " is an invalid array size");
            return;
        }

        int[] prices = new int[size];
        System.out.println("Enter the elements");
        for (int i = 0; i < size; i++) {
            prices[i] = sc.nextInt();
        }

        for (int i = 0; i < size; i++) {
            System.out.print(prices[i] + (i < size - 1 ? " " : ""));
        }
        System.out.print(" ");

        boolean ascending = true;
        boolean descending = true;

        for (int i = 1; i < size; i++) {
            if (prices[i] < prices[i - 1]) {
                ascending = false;
            }
            if (prices[i] > prices[i - 1]) {
                descending = false;
            }
        }

        if (ascending) {
            System.out.println("Array is sorted in ascending order");
        } else if (descending) {
            System.out.println("Array is sorted in descending order");
        } else {
            System.out.println("Array is unsorted");
        }
    }
}