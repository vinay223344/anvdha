import java.util.*;

class Vendor {
    private String vendorId;
    private String vendorName;
    private double ratePerProduct;
    private int productsSupplied;
    private double commissionRate;

    public Vendor(String vendorId, String vendorName, double ratePerProduct, int productsSupplied, double commissionRate) {
        this.vendorId = vendorId;
        this.vendorName = vendorName;
        this.ratePerProduct = ratePerProduct;
        this.productsSupplied = productsSupplied;
        this.commissionRate = commissionRate;
    }

    public String getVendorId() {
        return vendorId;
    }

    public String getVendorName() {
        return vendorName;
    }

    public double getRatePerProduct() {
        return ratePerProduct;
    }

    public int getProductsSupplied() {
        return productsSupplied;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public double calculatePayment() {
        // Constraints
        if (ratePerProduct <= 0 || productsSupplied <= 0 || commissionRate < 0 || commissionRate > 20) {
            return -1;
        }

        double basePayment = ratePerProduct * productsSupplied;
        double commission = (commissionRate / 100.0) * basePayment;
        return basePayment + commission;
    }
}