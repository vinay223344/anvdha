import java.util.*;
public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        VendorUtility utility = new VendorUtility();

        System.out.println("Enter vendor details:");
        String vendorDetails = sc.nextLine();

        Vendor vendor = utility.extractDetails(vendorDetails);

        if (vendor == null) {
            System.out.println("Invalid vendor details");
        } else {
            double payment = vendor.calculatePayment();
            if (payment == -1) {
                System.out.println("Invalid vendor details");
            } else {
                System.out.println("--- Vendor Payment Details ---");
                System.out.println("Vendor ID           : " + vendor.getVendorId());
                System.out.println("Vendor Name         : " + vendor.getVendorName());
                System.out.println("Rate per Product    : " + vendor.getRatePerProduct());
                System.out.println("Products Supplied   : " + vendor.getProductsSupplied());
                System.out.println("Commission Rate     : " + vendor.getCommissionRate() + "%");
                System.out.println("Total Payment Due   : " + payment);
            }
        }
    }
}