import java.util.*;
class VendorUtility {
    public Vendor extractDetails(String vendorDetails) {
        String[] parts = vendorDetails.split(",");
        if (parts.length != 5) {
            return null;
        }

        String vendorId = parts[0].trim();
        String vendorName = parts[1].trim();
        double ratePerProduct = Double.parseDouble(parts[2].trim());
        int productsSupplied = Integer.parseInt(parts[3].trim());
        double commissionRate = Double.parseDouble(parts[4].trim());

        return new Vendor(vendorId, vendorName, ratePerProduct, productsSupplied, commissionRate);
    }
}