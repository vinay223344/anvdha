import java.util.*;
public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        WildlifeSanctuary sanctuary = new WildlifeSanctuary();

        System.out.println("Enter the number of animals to add:");
        int n = sc.nextInt();
        sc.nextLine();

        System.out.println("Enter the animal details (AnimalName:Species):");
        for (int i = 0; i < n; i++) {
            String animalData = sc.nextLine();
            sanctuary.addAnimal(animalData);
        }

        System.out.println("Enter the species to retrieve animals:");
        String species = sc.nextLine();

        List<String> animals = sanctuary.getAnimalsBySpecies(species);

        if (animals.isEmpty()) {
            System.out.println("No animals found for the species " + species);
        } else {
            System.out.println("Animals for the species '" + species + "':");
            for (String animal : animals) {
                System.out.println(animal);
            }
        }
    }
}