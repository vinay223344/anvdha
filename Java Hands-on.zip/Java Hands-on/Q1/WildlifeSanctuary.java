import java.util.*;

class WildlifeSanctuary {

    private Map<String, String> sanctuaryRecords;

    public WildlifeSanctuary() {
        sanctuaryRecords = new HashMap<>();
    }

    public void addAnimal(String animalData) {
        String[] parts = animalData.split(":");
        if (parts.length == 2) {
            String animalName = parts[0].trim();
            String species = parts[1].trim();
            sanctuaryRecords.put(animalName, species);
        }
    }

    public List<String> getAnimalsBySpecies(String species) {
        List<String> animals = new ArrayList<>();
        for (Map.Entry<String, String> entry : sanctuaryRecords.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(species)) {
                animals.add(entry.getKey());
            }
        }
        return animals;
    }
}