import java.util.*;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of days:");
        int n = sc.nextInt();

        if (n <= 1) {
            System.out.println("Need at least 2 days to calculate profit.");
            return;
        }

        int[] prices = new int[n];
        System.out.println("Enter the stock prices for each day:");
        for (int i = 0; i < n; i++) {
            prices[i] = sc.nextInt();
        }

        int buyDay = -1;
        int sellDay = -1;
        int minPriceDay = 1;
        int minPrice = prices[0];
        int maxProfit = 0;

        for (int i = 1; i < n; i++) {
            int profit = prices[i] - minPrice;
            if (profit > maxProfit) {
                maxProfit = profit;
                buyDay = minPriceDay;
                sellDay = i + 1;
            }
            if (prices[i] < minPrice) {
                minPrice = prices[i];
                minPriceDay = i + 1;
            }
        }

        System.out.println("Stock Profit Summary:");
        if (maxProfit > 0) {
            System.out.println("To get the maximum profit of " + maxProfit +
                    ", buy on Day " + buyDay +
                    " and sell on Day " + sellDay + ".");
        } else {
            System.out.println("No profit could be made from the given prices.");
        }
    }
}