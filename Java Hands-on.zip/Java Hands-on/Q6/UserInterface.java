import java.util.*;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the size of the array");
        int size = sc.nextInt();

        if (size <= 0) {
            System.out.println(size + " is an invalid array size");
            return;
        }

        int[] arr = new int[size];
        System.out.println("Enter the elements of the array");
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }

        List<Integer> nonZeroList = new ArrayList<>();
        for (int num : arr) {
            if (num != 0) {
                nonZeroList.add(num);
            }
        }
        boolean isPalindrome = true;
        for (int i = 0; i < nonZeroList.size() / 2; i++) {
            if (!nonZeroList.get(i).equals(nonZeroList.get(nonZeroList.size() - 1 - i))) {
                isPalindrome = false;
                break;
            }
        }

        if (isPalindrome) {
            for (int i = 0; i < nonZeroList.size(); i++) {
                System.out.print(nonZeroList.get(i));
                if (i < nonZeroList.size() - 1) System.out.print(" ");
            }
            System.out.println(" is a palindrome array");
        } else {
            for (int i = 0; i < size; i++) {
                System.out.print(arr[i]);
                if (i < size - 1) System.out.print(" ");
            }
            System.out.println(" is not a palindrome array");
        }
    }
}
