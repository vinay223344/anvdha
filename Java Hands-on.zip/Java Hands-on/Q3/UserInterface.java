import java.util.*;
public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HotelManager manager = new HotelManager();

        System.out.println("Enter the number of hotels to be added");
        int n = Integer.parseInt(sc.nextLine());

        System.out.println("Enter hotel details (name : rating)");
        for (int i = 0; i < n; i++) {
            String hotelDetails = sc.nextLine();
            manager.addHotelDetails(hotelDetails);
        }

        System.out.println("Enter the minimum rating");
        double minRating = Double.parseDouble(sc.nextLine());

        List<String> hotels = manager.getHotelsByRating(minRating);

        if (hotels.isEmpty()) {
            System.out.println("No hotels were found with minimum rating of " + minRating);
        } else {
            System.out.println("Hotels with a rating of at least " + minRating + ":");
            for (String hotel : hotels) {
                System.out.println(hotel);
            }
        }
    }
}
