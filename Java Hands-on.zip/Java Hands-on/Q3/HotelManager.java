import java.util.*;

class HotelManager {
    private List<String> hotelList;

    public HotelManager() {
        hotelList = new ArrayList<>();
    }

    public void addHotelDetails(String hotelDetails) {
        hotelList.add(hotelDetails);
    }

    public List<String> getHotelsByRating(double minRating) {
        List<String> filteredHotels = new ArrayList<>();

        for (String hotel : hotelList) {
            String[] parts = hotel.split(":");
            if (parts.length == 2) {
                String hotelName = parts[0].trim();
                double rating = Double.parseDouble(parts[1].trim());

                if (rating >= minRating) {
                    filteredHotels.add(hotelName);
                }
            }
        }
        return filteredHotels;
    }
}